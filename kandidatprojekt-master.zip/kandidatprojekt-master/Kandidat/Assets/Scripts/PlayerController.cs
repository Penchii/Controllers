﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;





public class PlayerController : MonoBehaviour
{
	public CharacterController controller;
	public float gravityScale;
	public float moveSpeed;

	public Vector3 moveDirection;

    // Start is called before the first frame update
   void Start()
    {
		controller = GetComponent<CharacterController>();
        
    }
	
    // Update is called once per frame
    void Update()
    {
	
		moveDirection = new Vector3(Input.GetAxis("Horizontal") * moveSpeed, 0f, Input.GetAxis("Vertical") * moveSpeed);

        if (moveDirection != Vector3.zero)
        {
            transform.rotation = Quaternion.LookRotation(moveDirection);
        }
        
		moveDirection.y = (moveDirection.y + (Physics.gravity.y));
		controller.Move(moveDirection * Time.deltaTime);

    }
}
